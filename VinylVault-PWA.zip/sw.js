const CACHE_NAME = 'vinylvault-v1';
const BASE = self.location.pathname.replace(/sw\.js$/, '');
const PRECACHE = [
  BASE,
  BASE + 'index.html',
  BASE + 'app.js',
  BASE + 'manifest.webmanifest',
  BASE + 'icons/icon-192.png',
  BASE + 'icons/icon-512.png'
];

// Install — precache app shell
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(PRECACHE))
      .then(() => self.skipWaiting())
  );
});

// Activate — clean old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch — network-first for API, cache-first for app shell
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // Always go to network for Discogs API
  if (url.hostname === 'api.discogs.com') {
    e.respondWith(fetch(e.request));
    return;
  }

  // Cache-first for app shell files
  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      return fetch(e.request).then(response => {
        if (!response || response.status !== 200 || e.request.method !== 'GET') {
          return response;
        }
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(e.request, clone));
        return response;
      });
    }).catch(() => {
      if (e.request.mode === 'navigate') {
        return caches.match(BASE + 'index.html');
      }
    })
  );
});
